
Youtube
********
http://www.youtube.com/v/video_code_here
https://www.youtube.com/watch?feature=player_embedded&v=22CrPtjODPY&app=desktop
https://www.youtube.com/embed/DGD62Pan_z4
http://www.youtube.com/watch_popup?v=BNHR6IQJGZs
http://www.youtube.com/v/vr3x_RRJdd4 
youtube.com/watch?v=2mrRvUNlq50
youtube.com/watch_popup?v=2mrRvUNlq50

https://www.youtube.com/watch?v=WB370ewOklw         //How PayPal Works

Vimeo
********

https://vimeo.com/35514005
https://player.vimeo.com/video/35514005?autoplay=1

https://developer.vimeo.com/player/embedding

Facebook
********
https://www.facebook.com/video.php?v=10152541108348990
http://www.facebook.com/video/embed?video_id=10152541108348990