Regex Match Object
******************
    [0]https://www.youtube.com/watch?v=BKOlYDyo3sA
    [1]https://
    [2]www.youtube.com
    [3]www.
    [4]/watch?v=
    [5]BKOlYDyo3sA
    
Tab Object
***********
Array[1]
    0: Object
        active: true
        favIconUrl: "https://s.ytimg.com/yts/img/favicon_32-vflWoMFGx.pn"
        height: 753
        highlighted: true
        id: 185
        incognito: false
        index: 9
        pinned: false
        selected: true
        status: "complete"
        title: "How it works - YouTube"
        url: "https://www.youtube.com/watch?v=WB370ewOklw"
        width: 1439
        windowId: 22

0: "https://www.facebook.com/video.php?v=10152541108348990"
1: "https://"
2: "www.facebook.com"
3: "www."
4: "/video.php?v="
5: "10152541108348990"
            
0: "https://www.facebook.com/video.php?v=10152541108348990"
1: "https://"
2: "www.facebook.com"
3: "www."
4: "video/embed?video_id="5: "10152541108348990"

0: "https://vimeo.com/35514005?autoplay=1"
1: "https://"
2: "vimeo.com"
3: "/35514005?autoplay=1"

Array[6]
    0: "https://player.vimeo.com/video/35514005"
    1: "https://"
    2: "player."
    3: "vimeo.com"
    4: "/video/"
    5: "35514005"

Array[4]
    0: "vimeo.com/video/35514005"
    1: undefined
    2: "vimeo.com"
    3: "/video/35514005"index: 15input: "https://player.vimeo.com/video/35514005"length: 4__proto__: Array[0]