
Youtube
********
https://www.youtube.com/watch?v=WB370ewOklw         //How PayPal Works
https://www.youtube.com/embed/WB370ewOklw?autoplay=1
https://www.youtube.com/v/WB370ewOklw?autoplay=1
http://www.youtube.com/watch_popup?v=WB370ewOklw
https://www.youtube.com/embed/DGD62Pan_z4           //Restricted Video
https://www.youtube.com/watch?feature=player_embedded&v=22CrPtjODPY&app=desktop     //Updated in v 0.9.2
https://www.youtube.com/watch?v=-SQ2bvbmAMU&list=PLzufeTFnhupxIlcUF3d5tyRrr0CVpmAVh //Updated in v 0.9.4

Vimeo
********

https://vimeo.com/35514005      //New Vimeo
https://player.vimeo.com/video/35514005?autoplay=1

https://vimeo.com/59286998      //Timelapse Indai
https://player.vimeo.com/video/59286998?autoplay=1

Facebook
********
https://www.facebook.com/video.php?v=10152541108348990          //HowZat Cricket
http://www.facebook.com/video/embed?video_id=10152541108348990

https://www.facebook.com/video/embed?video_id=625719987572544   //Mauka Mauka Ad
https://www.facebook.com/video.php?v=625719987572544

DailyMotion
***********
http://www.dailymotion.com/video/x2kcwa1_major-lazer-dj-snake-lean-on-feat-mo-official-music-video_music
http://www.dailymotion.com/embed/video/x2kcwa1?autoStart=1

http://www.dailymotion.com/video/x182jt2
http://www.dailymotion.com/video/xsbrgx_hawaii-s-clouds-an-hdr-timelapse_travel     //Timelapse-Hawaii

Regex Test
***********
http://regexr.com/3am4m

Test
*****
chrome-extension://loehgplhpglddmnieioagfiofoflpakl/test.html 